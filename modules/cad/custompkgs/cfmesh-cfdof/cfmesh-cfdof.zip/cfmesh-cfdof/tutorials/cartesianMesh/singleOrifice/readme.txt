cfMesh Example Case
Date: 02 October 2014
Application: cartesianMesh

Goal: Demonstration of the regular expressions feature available within 
cfMesh for specifying patch names in the meshDict file.

STL File: singleOrifice.stl
STL Type: Multi-solid

Patches within the STL File (Note: Each patch is one STL Solid):
inlet_S11
outlet_S12
orificeRegion_S13
orificeRegion_S14
orificeRegion_S15
fixedWalls_S16
fixedWalls_S17
fixedWalls_S18
fixedWalls_S19







