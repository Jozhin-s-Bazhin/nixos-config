cfMesh Example Case
Date: 02 October 2014
Application: cartesianMesh

Goal: Demonstration of the regular expressions feature available within 
cfMesh for specifying patch names in the meshDict file.

STL File: elbow_90degree.stl
STL Type: Multi-solid

Patches within the STL File (Note: Each patch is one STL Solid):
inlet_S73
outlet_S74
bendOuter_S75
bendOuter_S76
bendInner_S77
ringArea_S78
fixedWalls_S79
fixedWalls_S80
fixedWalls_S81








