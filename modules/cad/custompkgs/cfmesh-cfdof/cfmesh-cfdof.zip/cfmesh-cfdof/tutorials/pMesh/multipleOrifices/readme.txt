cfMesh Example Case
Date: 08 June 2015
Application: pMesh

Goal: Demonstration of the regular expressions feature available within 
cfMesh for specifying patch names in the meshDict file.

STL File: multipleOrifices.stl
STL Type: Multi-solid

Patches within the STL File (Note: Each patch is one STL Solid):
inlet_S42
outlet_S43
orifice01_S44
orifice01_S45
orifice01_S46
orifice02_S47
orifice02_S48
orifice02_S49
orifice03_S50
orifice03_S51
orifice03_S52
orifice04_S53
orifice04_S54
orifice04_S55
orifice05_S56
orifice05_S57
orifice05_S58
orifice06_S59
orifice06_S60
orifice06_S61
tubes_S62
tubes_S63
tubes_S64
tubes_S65
tubes_S66
tubes_S67
tubes_S68
tubes_S69
tubes_S70
tubes_S71
tubes_S72
tubes_S73
fixedWalls_S74
fixedWalls_S75
fixedWalls_S76
fixedWalls_S77
fixedWalls_S78
fixedWalls_S79
fixedWalls_S80
fixedWalls_S81





